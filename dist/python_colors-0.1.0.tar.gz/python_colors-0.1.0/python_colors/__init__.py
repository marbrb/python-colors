# -*- coding: utf-8 -*-

"""Top-level package for python-colors."""

__author__ = """Miguel Angel Rodriguez Bermudez"""
__email__ = 'marbrb1@gmail.com'
__version__ = '0.1.0'
