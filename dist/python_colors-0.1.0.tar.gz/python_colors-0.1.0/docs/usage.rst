=====
Usage
=====

To use python-colors in a project::

    import colors

    print(colors.red('This text will be displayed on red color.'))
