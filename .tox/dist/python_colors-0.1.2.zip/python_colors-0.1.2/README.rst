=============
python-colors
=============


.. image:: https://img.shields.io/pypi/v/python_colors.svg
        :target: https://pypi.python.org/pypi/python_colors

.. image:: https://img.shields.io/travis/marbrb/python_colors.svg
        :target: https://travis-ci.org/marbrb/python_colors

.. image:: https://readthedocs.org/projects/python-colors/badge/?version=latest
        :target: https://python-colors.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status




Print colored text on UNIX terminals


* Free software: GNU General Public License v3
* Documentation: https://python-colors.readthedocs.io.


Features
--------

* Easy usage

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
