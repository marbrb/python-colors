=====
Usage
=====

To use python-colors in a project::

    # Available colors are: black, red, green, yellow, blue, purple, cyan, white
    from colors import red, green

    print(red('This text will be displayed on red color.'))
    print(green('This text will be displayed on green color.'))
