=======
History
=======

0.1.0 (2018-03-11)
------------------

* First release on PyPI.

0.1.1 (2018-11-16)
------------------

* Added a class for creating styles e.g. Bold, and the Coloring class was made
a little bit more abstract
